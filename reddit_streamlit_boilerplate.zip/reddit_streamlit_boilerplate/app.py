import streamlit as st
import requests

# Access secret
gnews_key = st.secrets["api_keys"]["gnews_api"]

st.title("📰 News Fetcher")
query = st.text_input("Enter search keyword:")

if query:
    url = f"https://gnews.io/api/v4/search?q={query}&token={gnews_key}&lang=en"
    response = requests.get(url)
    data = response.json()

    articles = data.get("articles", [])
    if articles:
        for article in articles:
            st.subheader(article["title"])
            st.write(article["description"])
            st.write(f"[Read more]({article['url']})")
            st.markdown("---")
    else:
        st.warning("No articles found.")
